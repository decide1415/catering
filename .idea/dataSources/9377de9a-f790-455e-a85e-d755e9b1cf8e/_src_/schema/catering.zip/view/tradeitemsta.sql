CREATE VIEW `tradeitemsta` AS
  SELECT
    `catering`.`td_trade_by_user`.`user_id`     AS `user_id`,
    `catering`.`td_trade_by_user`.`user_name`   AS `user_name`,
    `catering`.`td_trade_by_user`.`time`        AS `time`,
    `catering`.`td_trade_by_user`.`cotTCAbySTA` AS `TCAitem`,
    `catering`.`td_trade_by_user`.`cotTCBbySTA` AS `TCBitem`,
    `catering`.`td_trade_by_user`.`cotTCCbySTA` AS `TCCitem`,
    `catering`.`td_trade_by_user`.`count`       AS `count`
  FROM `catering`.`td_trade_by_user`