CREATE VIEW `tradeitemstb` AS
  SELECT
    `catering`.`td_trade_by_user`.`user_id`     AS `user_id`,
    `catering`.`td_trade_by_user`.`user_name`   AS `user_name`,
    `catering`.`td_trade_by_user`.`time`        AS `time`,
    `catering`.`td_trade_by_user`.`cotTCAbySTB` AS `TCAitem`,
    `catering`.`td_trade_by_user`.`cotTCBbySTB` AS `TCBitem`,
    `catering`.`td_trade_by_user`.`count`       AS `count`
  FROM `catering`.`td_trade_by_user`